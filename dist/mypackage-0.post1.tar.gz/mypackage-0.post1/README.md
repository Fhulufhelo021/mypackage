# my package

# how to install
...instruction